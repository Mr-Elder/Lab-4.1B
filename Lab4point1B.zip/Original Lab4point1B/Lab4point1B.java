public class Lab4point1B 
{
    
    public static void main(String[] args) 
    {
        final int FLIPS = 10; //number of coin flips
        final int HEADS = 0;
        final int TAILS = 1;
        
        int currentRun = 0;    //length of the current run of HEADS
        int maxRun = 0;        //length of the maximum run so far
        int runHold = 0;
		int countHeads = 0;
		int countTails = 0;
		int count = 0;
		double dblBias = 0.5;

		//Set the bias		
		dblBias = GetInfo.getDouble ("Enter a bias between 0 and 1: ");
        
        //Create a FAIR coin object
		
   		BiasedCoin coin = new BiasedCoin(); //instantaites a Fair Coin	

		if (dblBias != 0.5)
        	{
           		coin = new BiasedCoin(dblBias); //instantaites the BiasedCoin
        	}
        
        //Flip the coin FLIPS times
        for(int i = 0; i < FLIPS; i++)
        {
        	//Flip the coun & print the result
        	coin.flip();
        	
        	count++;
        	System.out.println("Coin flip #" + count +" was " + coin.toString());
        	
        	//Update the run information
        	
        	if(coin.getFace() == HEADS)
        	 {
        	 	currentRun++;
        	 	countHeads++;
        	 }
        	else 
        	 {
        	 	currentRun = 0;
        	 	countTails++;	
        	 }
        	 
        	 if(runHold < currentRun)
        	 {
        	 		runHold = currentRun;
        	 }
        	 maxRun = runHold;
        }
        
        //Print the results
        System.out.println();
        //System.out.println("The coin is has a " + (coin.getBias() * 100) + "/" + ((1.0 - coin.getBias()) * 100) +" chance of landing on heads");
        System.out.println("The coin landed on heads: " + countHeads + " out of " + FLIPS);
        System.out.println("The coin landed on heads " + maxRun + " times in a row");
    	System.out.println("The coin landed on tails: " + countTails + " out of " + FLIPS);
    	System.out.println();
    }
}
